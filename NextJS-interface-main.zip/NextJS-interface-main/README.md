# DexFin Swap Intergface -NEXTJS application

## How to run
1. Clone from repository 
  `git clone https://github.com/superstar1205/NextJS-interface.git`
2. Yarn Install
   `cd NextJS-interface` && `yarn`
3. Build project
  `yarn dev`
![mobile](https://user-images.githubusercontent.com/86986628/214487734-0fa6cc3f-63a5-4424-8b6d-f4f89525d27f.png)

## How to delpoy NextJS application

`Contact me`

*Dont forget give me star and follow me :)*
