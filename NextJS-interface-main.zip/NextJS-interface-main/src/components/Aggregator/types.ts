export interface ExtraData {
	userAddress: string
	slippage: string
}
