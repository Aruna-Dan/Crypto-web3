export const sm = 480 / 16
export const med = 812 / 16
export const lg = 1024 / 16
export const xl = 1400 / 16
export const twoXl = 1536 / 16
